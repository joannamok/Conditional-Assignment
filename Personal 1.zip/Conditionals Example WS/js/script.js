//Mokhtarezadeh_Joanna_4-23-13
// Teraries - Buying a new Car

var car = 12000;
var taxRefund = 3000;
var oldCar = 4000;
var loanTotal = 6000;

if(taxRefund + oldCar + loanTotal >= car){
	console.log("You get to buy your Minivan!");

}else{
	console.log("Sorry,no new minivan for you");
}

