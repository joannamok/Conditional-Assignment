//Mokhtarezadeh_Joanna_4-23-13
//4th Grade Recycling Contest - Over 500 items earns a Pizza Party

var waterBottles =180;
var sodaCans = 200;
var newspapers =100;
var magazines =120;
var pizzaParty;

pizzaParty = (waterBottles + sodaCans + newspapers + magazines > 500 ) ? "Congrats! Your class has gathered enough recyclables to earn a Pizza Party!!!" : "Sorry, your class did not earn enough for a Pizza Party, but you did help the environment!";
console.log(pizzaParty);