//Mokhtarezadeh_Joanna_4-23-13
// Free Shipping for purchase of 200 or more Swarovski Crystals

var ruby = 100;	// How many ruby Swarovski Crystals do you want? 

var peridot = 20; 	// How many peridot Swarovski Crystals do you want? 

var citrine = 20;	// How many citrine Swarovski Crystals do you want? 

var aquamarine = 59;	// How many aquamarine Swarovski Crystals do you want? 

var total = ruby + peridot + citrine + aquamarine; //This is the total of purchased crystals

var less = 200 - total; // How many more crystals needed to get Free Shipping?

//This is message that appears for customers receiving Free Shipping.
if(ruby + peridot + citrine + aquamarine >= 200 ){
	console.log("You get FREE Shipping with your purchase of"+" "+(total)+" "+"Swarovski Crystals!!");

}else{
	//This the message that appear for customers with less that 200 crystals. It also tells them how many more need to be purchased to recieve free shipping.
	console.log ("Wait! If you purchase just"+" "+(less)+" "+"more Swarovski Crystals you get FREE Shipping!!");
}
