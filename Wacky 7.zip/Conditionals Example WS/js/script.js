//Mokhtarezadeh_Joanna_4-23-13
//4th Grade Recycling Contest - Over 500 items earns a Pizza Party and T-shirts

var waterBottles =250; // How many waterbottles did your class gather?

var sodaCans = 250;	// How many soda cans did your class gather?

var newspapers =0;	//How many newspapers did your class gather?

var magazines =0;	//How many magazines did your class gather?

var pizzaParty; // A Pizza Parts is the prize for classes that gather over 500 items.

var colorBooks = "Coloring Book" // A coloring book is given to the classes that don't make the Pizza Party goal.

var tShirt = "T-shirts" // T shirts are also givin to the classes that gather over 500 items.

// This message states rather classes earned a Pizza Party for gahtering over 500 items or get a coloring book for gahtering less than the 500 goal. 
pizzaParty = (waterBottles + sodaCans + newspapers + magazines > 500 ) ? "Congrats! Your class has gathered enough recyclables to earn a Pizza Party and"+" "+(tShirt)+"!" : "Sorry, your class did not earn enough for a Pizza Party, but you did help the environment and everyone gets a"+" "+(colorBooks)+"!";
console.log(pizzaParty);