//Mokhtarezadeh_Joanna_4-23-13
// Buying a new Car
// tax refund,old car sale,and loan total must be equal to or over price of minivan
var minivan = 12000; // How much is the minivan you want?
var taxRefund = 4000; // How much did you get for a tax refund?
var oldCar = 4000;	//How much did you get for selling your old car?
var loanTotal = 4000; // How much did you get for a loan? 

// To get minivan, tax refund,old car sale,and loan total must be equal to or over price of minivan

if(taxRefund + oldCar + loanTotal >= minivan){

	console.log("You get to buy your Minivan!");

// If there is not enough money,this will be the message:
}else{
	console.log("Sorry,no new minivan for you");
}

