//Mokhtarezadeh_Joanna_4-23-13
// Free Shipping for 200 or more Crystals

var ruby = 45; 
var peridot = 48; 
var citrine = 96;
var aquamarine = 25;
var total = ruby + peridot + citrine + aquamarine;
var less = 200 - total;

if(ruby + peridot + citrine + aquamarine >= 200 ){
	console.log("You get FREE Shipping with your purchase of"+" "+(total)+" "+"Swarovski Crystals!!");

}else{
	console.log (less);
}
