//Mokhtarezadeh_Joanna_4-23-13
// Free Shipping for 200 or more Crystals

var ruby = 20; 
var peridot = 20; 
var citrine = 20;
var aquamarine = 20;
var total = ruby + peridot + citrine + aquamarine;
var less = 200 - total;

if(ruby + peridot + citrine + aquamarine >= 200 ){
	console.log("You get FREE Shipping with your purchase of"+" "+(total)+" "+"Swarovski Crystals!!");

}else{
	console.log ("Wait! If you purchase just"+" "+(less)+" "+"more Swarovski Crystals you get FREE Shipping!!");
}
