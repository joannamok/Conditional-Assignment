//Mokhtarezadeh_Joanna_4-23-13
//4th Grade Recycling Contest - Over 500 items earns a Pizza Party

var waterBottles =8;
var sodaCans = 0;
var newspapers =100;
var magazines =120;
var pizzaParty;

pizzaParty = (waterBottles + sodaCans + newspapers + magazines > 500 ) ? "yes" : "no";
console.log(pizzaParty);